
  # Create HTML Page

  This is a code bundle for Create HTML Page. The original project is available at https://www.figma.com/design/JrmuXIwqzv6VtHv9yvTzdp/Create-HTML-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  